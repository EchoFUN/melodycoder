
exports.login = function(req, resp) {
	
	req.session.isLogin = false;
}