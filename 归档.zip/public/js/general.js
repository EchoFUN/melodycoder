document.observe("dom:loaded", function() {


	

		
});